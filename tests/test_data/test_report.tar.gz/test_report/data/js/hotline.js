processed_hotline_data = {"data_name":"hotline","data_format":"unknown","runs":{}}

hotline_findings = {"per_run_findings":{}}