processed_flamegraphs_data = {"data_name":"flamegraphs","data_format":"unknown","runs":{}}

flamegraphs_findings = {"per_run_findings":{}}