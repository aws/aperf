processed_systeminfo_data = {"data_name":"systeminfo","data_format":"key_value","runs":{"test_run_1":{"key_value_groups":{"":{"key_values":{}}}},"test_run_2":{"key_value_groups":{"":{"key_values":{}}}}}}

systeminfo_findings = {"per_run_findings":{}}