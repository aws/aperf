processed_java_profile_data = {"data_name":"java_profile","data_format":"unknown","runs":{}}

java_profile_findings = {"per_run_findings":{}}